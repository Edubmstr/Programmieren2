package programmieren2.StudentUniversity;

public class Instructor {
    private String fullName;

    public Instructor(String fullName){
        this.fullName = fullName;
    }

    public String toString(){
        return this.fullName;
    }
}
